clear 

cd F:\traffic_speed\match-road-baiyun\speed_hour

x_time=linspace(0,23,24);

weekday_road_type_speed=dlmread('2018-05-08_road_type_speed_ave.txt',',',1,0);

plot(x_time,weekday_road_type_speed(1,:),'b-','linewidth',2)
hold on
plot(x_time,weekday_road_type_speed(2,:),'r-','linewidth',2)
hold on
plot(x_time,weekday_road_type_speed(3,:),'k-','linewidth',2)
hold on

weekend_road_type_speed=dlmread('2018-05-13_road_type_speed_ave.txt',',',1,0);

plot(x_time,weekend_road_type_speed(1,:),'b--','linewidth',2)
hold on
plot(x_time,weekend_road_type_speed(2,:),'r--','linewidth',2)
hold on
plot(x_time,weekend_road_type_speed(3,:),'k--','linewidth',2)
hold on


labelx={'00:00','04:00','08:00','12:00','16:00','20:00','24:00'};
set(gca,'XTick',[0, 4, 8, 12, 16, 20, 24]);
set(gca,'XTickLabel',labelx);
     set(gca,'XTickLabel',labelx);

     set(gca,'FontSize',12);
     
set(gca,'ylim',[15,135])
set(gca,'xlim',[-0.5,23.5])
legend1=legend('Freeway(Weekday)','Artery Road(Weekday)','Local Road(Weekday)','Freeway(Weekend)','Artery Road(Weekend)','Local Road(Weekend)');

set(legend1,'location','northeast');
ylabel('Traffic Speed / Unit: km/h','FontSize',18)
xlabel('Time (LST)','FontSize',18)