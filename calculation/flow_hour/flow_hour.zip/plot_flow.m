clear 

cd F:\traffic_speed\match-road-baiyun\flow_hour


x_time=linspace(0,23,24);

weekday_road_type_flow=dlmread('2018-05-08_road_type_flow_ave.txt',',',1,0);
% weekday_road_type_flow(1,:)=weekday_road_type_flow(1,:)*4;

plot(x_time,weekday_road_type_flow(1,:),'b-','linewidth',2)
hold on
plot(x_time,weekday_road_type_flow(2,:),'r-','linewidth',2)
hold on
plot(x_time,weekday_road_type_flow(3,:),'k-','linewidth',2)
hold on

weekend_road_type_flow=dlmread('2018-05-13_road_type_flow_ave.txt',',',1,0);
% weekend_road_type_flow(1,:)=weekend_road_type_flow(1,:)*4;

plot(x_time,weekend_road_type_flow(1,:),'b--','linewidth',2)
hold on
plot(x_time,weekend_road_type_flow(2,:),'r--','linewidth',2)
hold on
plot(x_time,weekend_road_type_flow(3,:),'k--','linewidth',2)
hold on


labelx={'00:00','04:00','08:00','12:00','16:00','20:00','24:00'};
set(gca,'XTick',[0, 4, 8, 12, 16, 20, 24]);
set(gca,'XTickLabel',labelx);
     set(gca,'XTickLabel',labelx);

     set(gca,'FontSize',12);
     
     
set(gca,'xlim',[-0.5,23.5])
set(gca,'ylim',[0,15000])
legend1=legend('Freeway(Weekday)','Artery Road(Weekday)','Local Road(Weekday)','Freeway(Weekend)','Artery Road(Weekend)','Local Road(Weekend)');

set(legend1,'location','northwest');
ylabel('Traffic Volume / Unit: pcu','FontSize',18)
xlabel('Time (LST)','FontSize',18)

%%%%%%%%%%%%%%%%%%%%%%

x_time=linspace(0,23,24);
weekday_flow=dlmread('2018-03-13_hour_flow.txt',',',1,0);
weekday_flow_total=nansum(weekday_flow,1);
weekend_flow=dlmread('2018-03-18_hour_flow.txt',',',1,0);
weekend_flow_total=nansum(weekend_flow,1);
%%%
plot(x_time,weekday_flow_total,'r','linewidth',2)
hold on
plot(x_time,weekend_flow_total,'b','linewidth',2)


%%% plot precentage
% plot(x_time,weekday_flow_total./nansum(weekday_flow_total)*100,'r','linewidth',2)
% hold on
% plot(x_time,weekend_flow_total./nansum(weekend_flow_total)*100,'b','linewidth',2)

legend1=legend('Weekday Flow','Weekend Flow');

%%%%%%% plot for 5-1 holiday
clear
close all
cd F:\traffic_speed\match-road-32\flow_hour
x_time=linspace(0,23,24);
weekday_flow_1=dlmread('2018-04-28_hour_flow.txt',',',1,0);
weekday_flow_total_1=nansum(weekday_flow_1,1);
weekday_flow_2=dlmread('2018-04-29_hour_flow.txt',',',1,0);
weekday_flow_total_2=nansum(weekday_flow_2,1);
weekday_flow_3=dlmread('2018-04-30_hour_flow.txt',',',1,0);
weekday_flow_total_3=nansum(weekday_flow_3,1);
weekday_flow_4=dlmread('2018-05-01_hour_flow.txt',',',1,0);
weekday_flow_total_4=nansum(weekday_flow_4,1);
weekday_flow_5=dlmread('2018-05-02_hour_flow.txt',',',1,0);
weekday_flow_total_5=nansum(weekday_flow_5,1);

weekday_flow_6=dlmread('2018-05-05_hour_flow.txt',',',1,0);
weekday_flow_total_6=nansum(weekday_flow_6,1);
weekday_flow_7=dlmread('2018-05-06_hour_flow.txt',',',1,0);
weekday_flow_total_7=nansum(weekday_flow_7,1);

weekday_flow_total_all=[weekday_flow_total_1;weekday_flow_total_2;weekday_flow_total_3;weekday_flow_total_4;weekday_flow_total_5;weekday_flow_total_6;weekday_flow_total_7]';


plot(x_time,weekday_flow_total_1,'^-','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_2,'^--','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_3,'o--','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_4,'x--','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_5,'o-','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_6,'^:','linewidth',1.5)
hold on
plot(x_time,weekday_flow_total_7,'o:','linewidth',1.5)
hold on


legend1=legend('28 Apr.','29 Apr.','30 Apr.','1 May.','2 May.','5 May.','6 May.');
set(legend1,'location','northwest');


labelx={'00:00','04:00','08:00','12:00','16:00','20:00','24:00'};
set(gca,'XTick',[0, 4, 8, 12, 16, 20, 24]);
set(gca,'XTickLabel',labelx);
     set(gca,'XTickLabel',labelx);

     set(gca,'FontSize',14);
     
     
set(gca,'xlim',[-0.5,23.5])



ylabel('Traffic Volume  (unit: pcu)','FontSize',14)
xlabel('Time (LST)','FontSize',14)
